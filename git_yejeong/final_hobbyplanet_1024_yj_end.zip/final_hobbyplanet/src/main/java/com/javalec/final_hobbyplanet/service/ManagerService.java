package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_hobbyplanet.dto.UserDTO;

public interface ManagerService {
	public ArrayList<UserDTO> listUser();
}
