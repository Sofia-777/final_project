package com.javalec.final_hobbyplanet.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_hobbyplanet.dto.UserDTO;

public interface ManagerDAO {
	public ArrayList<UserDTO> listUser();
}
