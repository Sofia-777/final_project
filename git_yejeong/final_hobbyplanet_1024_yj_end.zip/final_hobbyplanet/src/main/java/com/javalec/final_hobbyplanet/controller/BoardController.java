package com.javalec.final_hobbyplanet.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.BoardDTO;
import com.javalec.final_hobbyplanet.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	@Autowired
	public HttpSession session;
	
   @RequestMapping("/board/list")
   public String listBoard(Model model) {
	   ArrayList<BoardDTO> list = service.listBoard();
	   model.addAttribute("list", list);
	   
	   return "board/list";
   }

   @RequestMapping("/board/write")
   public String write() {
	   
	   return "board/write";
   }

   @RequestMapping("/board/write_ok")
   public String writeBoard(@RequestParam HashMap<String, String> param) {
	   service.insertBoard(param);
	   
	   return "redirect:list";
   }
   
   @RequestMapping("/board/show")
   public String getBoard(@RequestParam HashMap<String, String> param, Model model) {
	   service.hitBoard(param);
	   BoardDTO dto = service.getBoard(param);
	   model.addAttribute("getBoard", dto);
	   
	   return "board/show";
   }
   
   @RequestMapping("/board/edit")
   public String getEditBoard(@RequestParam HashMap<String, String> param, Model model) {
	   BoardDTO dto = service.getBoard(param);
	   model.addAttribute("getEditBoard", dto);
	   
	   return "board/edit";
   }
   
   @RequestMapping("/board/edit_ok")
   public String eidtBoard(@RequestParam HashMap<String, String> param) {
	   service.editBoard(param);
	   
	   return "redirect:list";
   }
   
   @RequestMapping("/board/delete")
   public String pwdBoard(@RequestParam HashMap<String, String> param, Model model) {
	   BoardDTO dto = service.getBoard(param);
	   model.addAttribute("getDeleteBoard", dto);
	   
	   return "board/delete";
   }
   
   @RequestMapping("/board/delete_ok")
   public String deleteBoard(@RequestParam HashMap<String, String> param) {
	   BoardDTO dto = service.pwdBoard(param);
	   
	   if (dto.getB_pwd().equals(param.get("b_pwd"))) {
		   service.deleteBoard(param);
		   
		   return "redirect:list";
	   } else {
		   return "redirect:list";
	   }
   }
}
