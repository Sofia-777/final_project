package com.javalec.final_hobbyplanet.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_hobbyplanet.dto.ManagerDTO;
import com.javalec.final_hobbyplanet.dto.UserDTO;

public interface UserDAO {
	public ArrayList<UserDTO> getUser(HashMap<String, String> param);
	public void register(HashMap<String, String> param);
	public ArrayList<ManagerDTO> getManager(HashMap<String, String> param);
}