package com.javalec.final_hobbyplanet.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.NoticeDTO;
import com.javalec.final_hobbyplanet.service.NoticeService;

@Controller
public class NoticeController {
	
	@Autowired
	private NoticeService service;
	
	@RequestMapping("/notice/listNotice")
	public String listNotice(Model model) {
		ArrayList<NoticeDTO> list = service.listNotice();
		model.addAttribute("listNotice", list);
		
		return "/notice/listNotice";
	}
	
	@RequestMapping("/notice/writeNotice")
	public String write() {
		return "/notice/writeNotice";
	}
	
	@RequestMapping("/notice/writeNotice_ok")
	public String writeNotice(@RequestParam HashMap<String, String> param) {
		service.writeNotice(param);
		
		return "redirect:listNotice";
	}
	
	@RequestMapping("/notice/showNotice")
	public String showNotice(@RequestParam HashMap<String, String> param, Model model) {
		service.upCount(param); // �Խñ� Ŭ���ϸ� ��ȸ��(count)�� �ø�
		
		NoticeDTO dto = service.showNotice(param);
		model.addAttribute("show", dto);
		
		return "/notice/showNotice";
	}
	
	@RequestMapping("/notice/editNotice")
	public String edit(@RequestParam HashMap<String, String> param, Model model) {
		NoticeDTO dto = service.showNotice(param);
		model.addAttribute("show", dto);
		
		return "/notice/editNotice";
	}
	
	@RequestMapping("/notice/editNotice_ok")
	public String editNotice(@RequestParam HashMap<String, String> param, Model model) {
		service.editNotice(param);
		
		return "redirect:listNotice";
	}
	
	@RequestMapping("/notice/deleteNotice_ok")
	public String deleteNotice(@RequestParam HashMap<String, String> param, Model model) {
		service.deleteNotice(param);
		
		return "redirect:listNotice";
	}
	
	
}
