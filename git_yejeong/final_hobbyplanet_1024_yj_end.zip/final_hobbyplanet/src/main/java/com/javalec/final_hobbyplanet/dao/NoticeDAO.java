package com.javalec.final_hobbyplanet.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_hobbyplanet.dto.NoticeDTO;


public interface NoticeDAO {
	public ArrayList<NoticeDTO> listNotice();
	public void writeNotice(HashMap<String, String> param);
	public NoticeDTO showNotice(HashMap<String, String> param);
	public void upCount(HashMap<String, String> param); // ��ȸ�� +1 �޼ҵ�
	public void editNotice(HashMap<String, String> param);
	public void deleteNotice(HashMap<String, String> param);
}
