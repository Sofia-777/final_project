package com.javalec.final_hobbyplanet.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.JoinDTO;
import com.javalec.final_hobbyplanet.service.JoinService;

// Service�� �޼ҵ���� ȣ��
@Controller
public class JoinContoller {
	
	@Autowired JoinService service;
	
	// ��� ����
	@RequestMapping("/join/listJoin")
	public String listJoin(Model model) {
		ArrayList<JoinDTO> list = service.listJoin();
		model.addAttribute("listJoin", list);
		
		return "join/listJoin";
	}
	
	// �� �ۼ� ��
	@RequestMapping("/join/writeJoin")
	public String writeJoin() {
		return "join/writeJoin";
	}
	
	// �� �ۼ�
	@RequestMapping("/join/writeJoin_ok")
	public String writeJoin_ok(@RequestParam HashMap<String, String> param) {
		service.writeJoin(param);
		
		return "redirect:listJoin";
	}
	
	// �󼼺���
	@RequestMapping("/join/viewJoin")
	public String viewJoin(@RequestParam HashMap<String, String> param, Model model) {
		service.upCountJoin(param);
		
		JoinDTO dto = service.viewJoin(param);
		model.addAttribute("viewJoin", dto);
		
		return "join/viewJoin";
	}
	
	// �� ���� ��
	@RequestMapping("/join/editJoin")
	public String editJoin(@RequestParam HashMap<String, String> param, Model model) {
		
		JoinDTO dto = service.viewJoin(param);
		model.addAttribute("viewJoin", dto);
		
		return "join/editJoin";
	}
	
	// �� ����
	@RequestMapping("/join/editJoin_ok")
	public String editJoin_ok(@RequestParam HashMap<String, String> param) {
		service.editJoin(param);
		
		return "redirect:listJoin";
	}
	
	// �� ���� ��
	@RequestMapping("/join/deleteJoin")
	public String deleteJoin(@RequestParam HashMap<String, String> param, Model model) {
		
		JoinDTO dto = service.viewJoin(param);
		model.addAttribute("viewJoin", dto);
		
		return "join/deleteJoin";
	}
	
	// ����
	@RequestMapping("/join/deleteJoin_ok")
	public String deleteJoin_ok(@RequestParam HashMap<String, String> param) {
		JoinDTO result = service.checkPwdJoin(param);
		
		if((result.getJ_pwd()).equals(param.get("j_pwd"))) {
			service.deleteJoin(param);
		
			return "redirect:listJoin";
		}
		
		else {
			return "redirect:listJoin";
		}
	}
	
}