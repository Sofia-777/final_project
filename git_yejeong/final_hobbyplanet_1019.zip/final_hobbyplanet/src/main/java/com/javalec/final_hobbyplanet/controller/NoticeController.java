package com.javalec.final_hobbyplanet.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.NoticeDTO;
import com.javalec.final_hobbyplanet.service.NoticeService;

@Controller
public class NoticeController {
	
	@Autowired
	private NoticeService service;
	
	@RequestMapping("/notice/notice")
	public String listNotice(Model model) {
		ArrayList<NoticeDTO> list = service.listNotice();
		model.addAttribute("listNotice", list);
		
		return "notice/notice";
	}
	
	@RequestMapping("/notice/write_view")
	public String write_view() {
		return "write_view";
	}
	
	@RequestMapping("/notice/writeNotice")
	public String writeNotice(@RequestParam HashMap<String, String> param) {
		service.writeNotice(param);
		
		return "redirect:notice";
	}
}
