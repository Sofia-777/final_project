package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_hobbyplanet.dto.NoticeDTO;

public interface NoticeService {
	public ArrayList<NoticeDTO> listNotice();
	public void writeNotice(HashMap<String, String> param);
}
