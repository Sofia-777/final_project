package com.javalec.final_hobbyplanet.dto;

import java.sql.Timestamp;

//u_id       VARCHAR2(15)     PRIMARY KEY,    -- ���� ���̵�
//u_pwd      VARCHAR2(15)     NOT NULL,       -- ���� ��й�ȣ
//u_nickname VARCHAR2(30)     NOT NULL,       -- ���� �г���
//u_name     VARCHAR2(20)     NOT NULL,       -- ���� �̸�
//u_age_y    NUMBER(4)        NOT NULL,       -- ���� ����(��)(4�ڸ�)
//u_age_m    NUMBER(2)        NOT NULL,       -- ���� ����(��)(2�ڸ�)
//u_age_d    NUMBER(2)        NOT NULL,       -- ���� ����(��)(2�ڸ�)
//u_email    VARCHAR2(50)     NOT NULL,       -- ���� �̸���
//u_tel1     NUMBER(3)        NOT NULL,       -- ���� ��ȭ��ȣ1
//u_tel2     NUMBER(4)        NOT NULL,       -- ���� ��ȭ��ȣ2
//u_tel3     NUMBER(4)        NOT NULL,       -- ���� ��ȭ��ȣ3
//u_addr     VARCHAR2(150)    NOT NULL,       -- ���� �ּ�
//u_gender   VARCHAR2(6)      NOT NULL,       -- ���� ����(select)
//u_regdate  DATE                             -- ���� ��������

public class UserDTO {
	String u_id;
	String u_pwd;
	String u_nickname;
	String u_name;
	int u_age_y;
	int u_age_m;
	int u_age_d;
	String u_email;
	int u_tel1;
	int u_tel2;
	int u_tel3;
	String u_addr;
	String u_gender;
	Timestamp u_regdate;
	
	public UserDTO() {}
	
	public UserDTO(String u_id, String u_pwd, String u_nickname, String u_name, int u_age_y, int u_age_m, int u_age_d,
			String u_email, int u_tel1, int u_tel2, int u_tel3, String u_addr, String u_gender, Timestamp u_regdate) {
		this.u_id = u_id;
		this.u_pwd = u_pwd;
		this.u_nickname = u_nickname;
		this.u_name = u_name;
		this.u_age_y = u_age_y;
		this.u_age_m = u_age_m;
		this.u_age_d = u_age_d;
		this.u_email = u_email;
		this.u_tel1 = u_tel1;
		this.u_tel2 = u_tel2;
		this.u_tel3 = u_tel3;
		this.u_addr = u_addr;
		this.u_gender = u_gender;
		this.u_regdate = u_regdate;
	}

	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pwd() {
		return u_pwd;
	}
	public void setU_pwd(String u_pwd) {
		this.u_pwd = u_pwd;
	}
	public String getU_nickname() {
		return u_nickname;
	}
	public void setU_nickname(String u_nickname) {
		this.u_nickname = u_nickname;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public int getU_age_y() {
		return u_age_y;
	}
	public void setU_age_y(int u_age_y) {
		this.u_age_y = u_age_y;
	}
	public int getU_age_m() {
		return u_age_m;
	}
	public void setU_age_m(int u_age_m) {
		this.u_age_m = u_age_m;
	}
	public int getU_age_d() {
		return u_age_d;
	}
	public void setU_age_d(int u_age_d) {
		this.u_age_d = u_age_d;
	}
	public String getU_email() {
		return u_email;
	}
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
	public int getU_tel1() {
		return u_tel1;
	}
	public void setU_tel1(int u_tel1) {
		this.u_tel1 = u_tel1;
	}
	public int getU_tel2() {
		return u_tel2;
	}
	public void setU_tel2(int u_tel2) {
		this.u_tel2 = u_tel2;
	}
	public int getU_tel3() {
		return u_tel3;
	}
	public void setU_tel3(int u_tel3) {
		this.u_tel3 = u_tel3;
	}
	public String getU_addr() {
		return u_addr;
	}
	public void setU_addr(String u_addr) {
		this.u_addr = u_addr;
	}
	public String getU_gender() {
		return u_gender;
	}
	public void setU_gender(String u_gender) {
		this.u_gender = u_gender;
	}
	public Timestamp getU_regdate() {
		return u_regdate;
	}
	public void setU_regdate(Timestamp u_regdate) {
		this.u_regdate = u_regdate;
	}
}