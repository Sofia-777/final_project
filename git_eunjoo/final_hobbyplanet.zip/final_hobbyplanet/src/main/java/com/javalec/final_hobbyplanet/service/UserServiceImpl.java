package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.UserDAO;
import com.javalec.final_hobbyplanet.dto.UserDTO;

@Service("UserService")
public class UserServiceImpl implements UserService {
	
	@Autowired
	private SqlSession sqlsession;

	@Override
	public ArrayList<UserDTO> getUser(HashMap<String, String> param) {
		UserDAO dao = sqlsession.getMapper(UserDAO.class);
		ArrayList<UserDTO> dto = dao.getUser(param);
		
		return dto;
	}

	@Override
	public void register(HashMap<String, String> param) {
		UserDAO dao = sqlsession.getMapper(UserDAO.class);
		dao.register(param);
	}
}