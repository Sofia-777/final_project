package com.javalec.final_hobbyplanet.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.UserDTO;
import com.javalec.final_hobbyplanet.service.UserService;

@Controller
public class UserController {
   
   @Autowired
   private UserService service;

   @Autowired
   public HttpSession session;
   
   @RequestMapping("/user/userLogin")
   public String userLogin() {
      return "user/userLogin";
   }
   
   @RequestMapping("/user/login")
   public String login(@RequestParam HashMap<String, String> param, Model model) {
      ArrayList<UserDTO> dto = service.getUser(param);
      
      int result;
      
      if(dto.isEmpty()) {
         result = -1;
      }
      
      else {
         if((param.get("u_pwd").equals(dto.get(0).getU_pwd()))) {
            result = 1;
            
            session.setAttribute("u_id", param.get("u_id"));
               session.setAttribute("u_nickname", dto.get(0).getU_nickname());
               session.setAttribute("User", "yes");
               session.setMaxInactiveInterval(1800);
         }
         
         else {
            result = 0;
         }
      }
      
      if(result == 1) {
         return "redirect:../index";
      }
      
      return "redirect:user/userLogin";
   }
   
   @RequestMapping("/user/userLogin_ok")
   public String userLogin_ok() {
      return "../index";
   }
   
   @RequestMapping("/user/userLogout")
   public String userLogout() {
      
      session.invalidate();
      
      return "redirect:../index";
   }
   
   @RequestMapping("/user/userRegister")
   public String userRegister() {
      return "user/userRegister";
   }
   
   @RequestMapping("/user/userRegister_ok")
   public String userRegister_ok(@RequestParam HashMap<String, String> param) {
      service.register(param);
      
      return "redirect:userLogin";
   }
}