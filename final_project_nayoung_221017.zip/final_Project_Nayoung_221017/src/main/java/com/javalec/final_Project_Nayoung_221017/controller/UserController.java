package com.javalec.final_Project_Nayoung_221017.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_Project_Nayoung_221017.dto.UserDto;
import com.javalec.final_Project_Nayoung_221017.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService service;
	
	
	@RequestMapping("/userLogin")
	public String userLogin() {
		System.out.println("@@@### userLogin()");
		
		return "user/userLogin";
	}
	
	@RequestMapping("/login_yn")
	public String login_yn(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### login_yn()");
		
		ArrayList<UserDto> dtos = service.loginYn(param);
		
		if (dtos.isEmpty()) {
			return "redirect:user/userLogin";
		}else {
			if (param.get("u_pwd").equals(dtos.get(0).getU_pwd())) {
				return "redirect:login_ok";
			}else {
				return "redirect:user/userLogin";
			}
		}
		
	}
	@RequestMapping("/login_ok")
	public String login_ok() {
		System.out.println("@@@### login_ok()");
		
		return "user/login_ok";
	}
	
	@RequestMapping("/userRegister")
	public String userRegister() {
		System.out.println("@@@### userRegister()");
		
		return "user/userRegister";
	}
	
	@RequestMapping("/registerOk")
	public String registerOk(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### registerOk()");
		
		service.write(param);
		
		return "redirect:userLogin";
	}
}
