package com.javalec.final_Project_Nayoung_221017.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_Project_Nayoung_221017.dto.UserDto;

public interface UserService {
	public ArrayList<UserDto> loginYn(HashMap<String, String> param);
	public void write(HashMap<String, String> param);
}
