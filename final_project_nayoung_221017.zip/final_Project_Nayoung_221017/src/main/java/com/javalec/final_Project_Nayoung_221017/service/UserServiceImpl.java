package com.javalec.final_Project_Nayoung_221017.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_Project_Nayoung_221017.dao.*;
import com.javalec.final_Project_Nayoung_221017.dto.UserDto;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private SqlSession sqlSession;

	
	@Override
	public ArrayList<UserDto> loginYn(HashMap<String, String> param) {
		UserDao dao = sqlSession.getMapper(UserDao.class);
		ArrayList<UserDto> dtos = dao.loginYn(param);
		return dtos;
	}

	@Override
	public void write(HashMap<String, String> param) {
		UserDao dao = sqlSession.getMapper(UserDao.class);
		dao.write(param);
	}

}
