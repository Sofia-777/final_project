package com.javalec.final_Project_Nayoung_221018.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.javalec.final_Project_Nayoung_221018.dto.*;

public interface UserDao {
	public ArrayList<UserDto> loginYn(HashMap<String, String> param);
	public void write(HashMap<String, String> param);
}
