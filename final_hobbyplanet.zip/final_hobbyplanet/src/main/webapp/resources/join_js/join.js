function wirte_check_ok() {
	if(join_frm.j_city.value.length == 0){	
		alert("장소 대분류를 입력하세요.");
		join_frm.j_city.focus();
		return;
	} 
	
	if(join_frm.j_location.value.length == 0){	
		alert("장소 소분류를 입력하세요.");
		join_frm.j_location.focus();
		return;
	} 
	
	if(join_frm.j_hobbyB.value.length == 0){	
		alert("취미 대분류를 입력하세요.");
		join_frm.j_hobbyB.focus();
		return;
	} 
	
	if(join_frm.j_hobbyS.value.length == 0){	
		alert("취미 소분류를 입력하세요.");
		join_frm.j_hobbyS.focus();
		return;
	}
	 
	if(join_frm.j_Dday.value.length == 0){	
		alert("마감 일자를 입력하세요.");
		join_frm.j_Dday.focus();
		return;
	}  
	
	if(join_frm.j_Mday.value.length == 0){	
		alert("만나는 날을 입력하세요.");
		join_frm.j_Mday.focus();
		return;
	} 
	
	if(join_frm.j_cost.value.length == 0){	
		alert("비용 유무를 입력하세요.");
		join_frm.j_cost.focus();
		return;
	} 
	
	if(join_frm.j_maxmem.value.length == 0){	
		alert("최대인원를 입력하세요.");
		join_frm.j_maxmem.focus();
		return;
	} 
	
	if(join_frm.j_title.value.length == 0){	
		alert("제목을 입력하세요.");
		join_frm.j_title.focus();
		return;
	} 
	
	if(join_frm.j_content.value.length == 0){	
		alert("내용을 입력하세요.");
		join_frm.j_content.focus();
		return;
	} 
	
	if(join_frm.j_pwd.value.length == 0){	
		alert("암호를 입력하세요.");
		join_frm.j_pwd.focus();
		return;
	} 
	
	alert("글 작성 성공!");	
	document.join_frm.submit();
}



function edit_check_ok() {
	if(edit_frm.j_city.value.length == 0){	
		alert("장소 대분류를 입력하세요.");
		edit_frm.j_city.focus();
		return;
	} 
	
	if(edit_frm.j_location.value.length == 0){	
		alert("장소 소분류를 입력하세요.");
		edit_frm.j_location.focus();
		return;
	} 
	
	if(edit_frm.j_hobbyB.value.length == 0){	
		alert("취미 대분류를 입력하세요.");
		edit_frm.j_hobbyB.focus();
		return;
	} 
	
	if(edit_frm.j_hobbyS.value.length == 0){	
		alert("취미 소분류를 입력하세요.");
		edit_frm.j_hobbyS.focus();
		return;
	}
	 
	if(edit_frm.j_Dday.value.length == 0){	
		alert("마감 일자를 입력하세요.");
		edit_frm.j_Dday.focus();
		return;
	}  
	
	if(edit_frm.j_Mday.value.length == 0){	
		alert("만나는 날을 입력하세요.");
		edit_frm.j_Mday.focus();
		return;
	} 
	
	if(edit_frm.j_cost.value.length == 0){	
		alert("비용 유무를 입력하세요.");
		edit_frm.j_cost.focus();
		return;
	} 
	
	if(edit_frm.j_maxmem.value.length == 0){	
		alert("최대인원를 입력하세요.");
		edit_frm.j_maxmem.focus();
		return;
	} 
	
	if(edit_frm.j_title.value.length == 0){	
		alert("제목을 입력하세요.");
		edit_frm.j_title.focus();
		return;
	} 
	
	if(edit_frm.j_content.value.length == 0){	
		alert("내용을 입력하세요.");
		edit_frm.j_content.focus();
		return;
	} 
	
	if(edit_frm.j_pwd.value.length == 0){	
		alert("암호를 입력하세요.");
		edit_frm.j_pwd.focus();
		return;
	} 
	
	
	if(edit_frm.j_pwd_check.value != edit_frm.j_pwd.value) {
		alert("암호가 일치하지 않습니다.");
		edit_frm.j_pwd.focus();
		return;
	}

	alert("글 수정 성공!");	
	document.edit_frm.submit();
}

function delete_ok() {
	if(del_form.j_pwd.value.length == 0){	
		alert("비밀번호를 입력하세요.");
		del_form.j_pwd.focus();
		return;
	} 
	
	if(del_form.j_pwd_check.value != del_form.j_pwd.value) {
		alert("암호가 일치하지 않습니다.");
		del_form.j_pwd.focus();
		return;
	}
	
	alert("글 삭제 성공!");	
	document.del_form.submit();
}

function comment_ok() {
	if(reply_frm.jc_content.value.length == 0){	
		alert("댓글 내용을 입력하세요.");
		reply_frm.jc_content.focus();
		return;
	} 
	document.reply_frm.submit();
}