/* 회원 가입시 거쳐가는 함수 */
function register_ok() {
   /* 아이디를 설정하기 위해 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_id.value.length == 0) {
      alert("아이디를 써주세요.");
      register_form.u_id.focus();
      return;
   }

   /* 아이디를 양식에 맞게 적었는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_id.value.length < 6) {
      alert("아이디는 6글자 이상이어야 합니다.");
      register_form.u_id.focus();
      return;
   }
   
   /* 비밀번호를 설정하기 위해 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_pwd.value.length == 0) {
      alert("비밀번호를 써주세요.");
      register_form.u_pwd.focus();
      return;
   }
   
   /* 비밀번호를 양식에 맞게 적었는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_pwd.value.length < 6) {
      alert("비밀번호는 6글자 이상이어야 합니다.");
      register_form.u_pwd.focus();
      return;
   }
   
   /* 비밀번호 확인을 위해 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_pwd_check.value.length == 0) {
      alert("비밀번호 확인을 해주셔야 합니다.");
      register_form.u_pwd_check.focus();
      return;
   }
   
   /* 확인을 위해 적은 비밀번호와 설정을 위해 적은 비밀번호가 같은지 판단 */
   if(register_form.u_pwd_check.value != register_form.u_pwd.value) {
      alert("비밀번호가 일치하지 않습니다.");
      register_form.u_pwd_check.focus();
      return;
   }
   
   /* 닉네임을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_nickname.value.length == 0) {
      alert("닉네임을 써주세요.");
      register_form.u_nickname.focus();
      return;
   }
   
   /* 닉네임을 양식에 맞게 적었는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_nickname.value.length < 4) {
      alert("닉네임은 4글자 이상이어야 합니다.");
      register_form.u_nickname.focus();
      return;
   }
   
   /* 이름을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_name.value.length == 0) {
      alert("이름을 써주세요.");
      register_form.u_name.focus();
      return;
   }
   
   /* 이메일을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_email.value.length == 0) {
      alert("Email을 써주세요.");
      register_form.u_email.focus();
      return;
   }

   /* 전화번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_tel2.value.length == 0) {
      alert("전화번호2를 써주세요.");
      register_form.u_tel2.focus();
      return;
   }
   /* 전화번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_tel3.value.length == 0) {
      alert("전화번호3를 써주세요.");
      register_form.u_tel3.focus();
      return;
   }
   
   /* 우편번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_addr1.value.length == 0 || register_form.u_addr2.value.length == 0) {
      alert("주소를 써주세요.");
      register_form.u_addr1.focus();
      return;
   }

   /* 상세주소를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(register_form.u_addr3.value.length == 0) {
      alert("상세 주소를 써주세요.");
      register_form.u_addr3.focus();
      return;
   }
   
   /* 확인 후 submit을 전송하여 jsp파일로 이동 */
   document.register_form.submit();
}


/* 회원정보 수정시 거쳐가는 함수 */
function update_check() {
   /* 비밀번호를 설정하기 위해 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_pwd.value.length == 0) {
      alert("비밀번호를 써주세요.");
      update_form.u_pwd.focus();
      return;
   }
   
   /* 비밀번호를 양식에 맞게 적었는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_pwd.value.length < 6) {
      alert("비밀번호는 6글자 이상이어야 합니다.");
      update_form.u_pwd.focus();
      return;
   }
   
   /* 비밀번호 확인을 위해 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_pwd_check.value.length == 0) {
      alert("비밀번호 확인을 해주셔야 합니다.");
      update_form.u_pwd_check.focus();
      return;
   }
   
   /* 확인을 위해 적은 비밀번호와 설정을 위해 적은 비밀번호가 같은지 판단 */
   if(update_form.u_pwd_check.value != update_form.u_pwd.value) {
      alert("비밀번호가 일치하지 않습니다.");
      update_form.u_pwd_check.focus();
      return;
   }
   
   /* 닉네임을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_nickname.value.length == 0) {
      alert("닉네임을 써주세요.");
      update_form.u_nickname.focus();
      return;
   }
   
   /* 닉네임을 양식에 맞게 적었는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_nickname.value.length < 4) {
      alert("닉네임은 4글자 이상이어야 합니다.");
      update_form.u_nickname.focus();
      return;
   }
   
   /* 이름을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_name.value.length == 0) {
      alert("이름을 써주세요.");
      update_form.u_name.focus();
      return;
   }
   
   /* 이메일을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_email.value.length == 0) {
      alert("Email을 써주세요.");
      update_form.u_email.focus();
      return;
   }
   
   /* 전화번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_tel1.value.length == 0) {
      alert("전화번호를 써주세요.");
      update_form.u_tel1.focus();
      return;
   }
   /* 전화번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_tel2.value.length == 0) {
      alert("전화번호를 써주세요.");
      update_form.u_tel2.focus();
      return;
   }
   /* 전화번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_tel3.value.length == 0) {
      alert("전화번호를 써주세요.");
      update_form.u_tel3.focus();
      return;
   }
   
   
   /* 우편번호를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_addr1.value.length == 0) {
      alert("우편번호를 써주세요.");
      update_form.u_addr1.focus();
      return;
   }
   /* 도로명 주소를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_addr2.value.length == 0) {
      alert("도로명 주소를 써주세요.");
      update_form.u_addr2.focus();
      return;
   }
   /* 상세주소를 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_addr3.value.length == 0) {
      alert("상세주소를 써주세요.");
      update_form.u_addr3.focus();
      return;
   }
   
   /* 성별을 입력 하였는지 input에 적힌 글자수로 입력 확인 */
   if(update_form.u_gender.value.length == 0) {
      alert("성별을 선택해주세요.");
      update_form.u_gender.focus();
      return;
   }
   
   /* 확인 후 submit을 전송하여 jsp파일로 이동 */
   alert("수정 성공!");
   document.update_form.submit();
}