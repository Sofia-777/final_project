package com.javalec.final_hobbyplanet.dto;

//city        VARCHAR2(100)   NOT NULL
//hobby           VARCHAR2(50)    NOT NULL

public class CategoryDTO {
	private String city;
	private String hobby;
	
	public CategoryDTO() {}
	
	public CategoryDTO(String city, String hobby) {
		this.city = city;
		this.hobby = hobby;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
}