package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.BoardCommentDAO;
import com.javalec.final_hobbyplanet.dto.BoardCommentDTO;

@Service("BoardCommentService")
public class BoardCommentServiceImpl implements BoardCommentService{
	
	@Autowired
	private SqlSession sqlsession;

	@Override
	public void insertBoardComment(HashMap<String, String> param) {
		BoardCommentDAO dao = sqlsession.getMapper(BoardCommentDAO.class);
		dao.insertBoardComment(param);
	}

	@Override
	public ArrayList<BoardCommentDTO> listBoardComment(HashMap<String, String> param) {
		BoardCommentDAO dao = sqlsession.getMapper(BoardCommentDAO.class);
		ArrayList<BoardCommentDTO> dtos = dao.listBoardComment(param);
		
		return dtos;
	}

	@Override
	public void deleteBoardComment(HashMap<String, String> param) {
		BoardCommentDAO dao = sqlsession.getMapper(BoardCommentDAO.class);
		dao.deleteBoardComment(param);
	}
	
	@Override
	public void deleteComment(HashMap<String, String> param) {
		BoardCommentDAO dao = sqlsession.getMapper(BoardCommentDAO.class);
		dao.deleteComment(param);
	}

	@Override
	public void editBoardComment(HashMap<String, String> param) {
		BoardCommentDAO dao = sqlsession.getMapper(BoardCommentDAO.class);
		dao.editBoardComment(param);
	}

}
