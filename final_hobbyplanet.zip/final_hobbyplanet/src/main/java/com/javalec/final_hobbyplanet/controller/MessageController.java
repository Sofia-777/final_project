package com.javalec.final_hobbyplanet.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.final_hobbyplanet.dto.MessageDTO;
import com.javalec.final_hobbyplanet.service.MessageService;

// Service�� �޼ҵ���� ȣ��
@Controller
public class MessageController {
	
	@Autowired MessageService service;
	
	// ���� ����Ʈ
	@RequestMapping("/message/listMessage")
	public String listMessage(@RequestParam HashMap<String, String> param, Model model) {
		ArrayList<MessageDTO> list = service.listMessage(param);

		model.addAttribute("listMessage", list);

		return "/message/listMessage";
	}
	
	// ���� �󼼺���
	@RequestMapping("/message/viewMessage")
	public String viewMessage(@RequestParam HashMap<String, String> param, Model model) {
		MessageDTO dto = service.viewMessage(param);
		
		model.addAttribute("viewMessage", dto);
		
		return "message/viewMessage";
	}
	
	// ���� ����
	@RequestMapping("/message/deleteMessage")
	public String deleteMessage(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		String encodedParam = URLEncoder.encode(param.get("u_nickname"), "UTF-8");
		
		service.deleteMessage(param);
		
		return "redirect:listMessage?u_nickname=" + encodedParam;
	}
}