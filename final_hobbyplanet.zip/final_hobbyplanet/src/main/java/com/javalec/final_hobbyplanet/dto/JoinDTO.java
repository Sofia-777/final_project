package com.javalec.final_hobbyplanet.dto;

import java.sql.Timestamp;

//j_idx       NUMBER(4)       PRIMARY KEY,                         -- ������ �۹�ȣ
//j_id        VARCHAR2(15)    REFERENCES USERTABLE(u_id),          -- ������ �ۼ���/������ ���̵�(����)
//j_nickname  VARCHAR2(30)    NOT NULL,                            -- ������ �ۼ���/������ �г���
//j_city      VARCHAR2(10)    NOT NULL,                            -- ������ ���� ��з�(select)
//j_location  VARCHAR2(100)   NOT NULL,                            -- ������ ���� �Һз�(text)
//j_hobbyB    VARCHAR2(50)    NOT NULL,                            -- ������ ��� ��з�(select)
//j_hobbyS    VARCHAR2(100)   NOT NULL,                            -- ������ ��� �Һз�(text)
//j_title     VARCHAR2(80)    NOT NULL,                            -- ������ ����
//j_date      DATE            DEFAULT SYSDATE,                     -- ������ �ۼ�����
//j_Dday      DATE            NOT NULL,                            -- ������ ��������(���� �޷�/text)
//j_Mday      DATE            NOT NULL,                            -- ������ ������ ����(���� �޷�/text)
//j_count     NUMBER(5)       DEFAULT 0,                           -- ������ ��ȸ��
//j_cost      VARCHAR2(2)              ,                           -- ������ ��� ����(üũ�ڽ�)
//j_maxmem    NUMBER(2)       NOT NULL,                            -- ������ �ִ��ο�(text)
//j_nowmem    NUMBER(2)       NOT NULL,                            -- ������ �����ο�
//j_content   VARCHAR2(3000)  NOT NULL,                            -- ������ ����
//j_pwd       VARCHAR(12)     NOT NULL,                            -- ������ ��й�ȣ
//j_end       NUMBER(1)       NOT NULL,                            -- ������ ���� ����
//j_admindel  NUMBER(1)       DEFAULT 1                            -- ������ ������ ���� ����  

public class JoinDTO {
	private int j_idx;
	private String j_id;
	private String j_nickname;
	private String j_city;
	private String j_location;
	private String j_hobbyB;
	private String j_hobbyS;
	private String j_title;
	private Timestamp j_date;
	private Timestamp j_Dday;
	private Timestamp j_Mday;
	private int j_count;
	private String j_cost;
	private int j_maxmem;
	private int j_nowmem;
	private String j_content;
	private String j_pwd;
	private int j_end;
	private int j_admindel;

	public JoinDTO() {}

	public JoinDTO(int j_idx, String j_id, String j_nickname, String j_city, String j_location, String j_hobbyB,
			String j_hobbyS, String j_title, Timestamp j_date, Timestamp j_Dday, Timestamp j_Mday, int j_count,
			String j_cost, int j_maxmem, int j_nowmem, String j_content, String j_pwd, int j_end, int j_admindel) {
		this.j_idx = j_idx;
		this.j_id = j_id;
		this.j_nickname = j_nickname;
		this.j_city = j_city;
		this.j_location = j_location;
		this.j_hobbyB = j_hobbyB;
		this.j_hobbyS = j_hobbyS;
		this.j_title = j_title;
		this.j_date = j_date;
		this.j_Dday = j_Dday;
		this.j_Mday = j_Mday;
		this.j_count = j_count;
		this.j_cost = j_cost;
		this.j_maxmem = j_maxmem;
		this.j_nowmem = j_nowmem;
		this.j_content = j_content;
		this.j_pwd = j_pwd;
		this.j_end = j_end;
		this.j_admindel = j_admindel;
	}
	public int getJ_idx() {
		return j_idx;
	}
	public void setJ_idx(int j_idx) {
		this.j_idx = j_idx;
	}
	public String getJ_id() {
		return j_id;
	}
	public void setJ_id(String j_id) {
		this.j_id = j_id;
	}
	public String getJ_nickname() {
		return j_nickname;
	}
	public void setJ_nickname(String j_nickname) {
		this.j_nickname = j_nickname;
	}
	public String getJ_city() {
		return j_city;
	}
	public void setJ_city(String j_city) {
		this.j_city = j_city;
	}
	public String getJ_location() {
		return j_location;
	}
	public void setJ_location(String j_location) {
		this.j_location = j_location;
	}
	public String getJ_hobbyB() {
		return j_hobbyB;
	}
	public void setJ_hobbyB(String j_hobbyB) {
		this.j_hobbyB = j_hobbyB;
	}
	public String getJ_hobbyS() {
		return j_hobbyS;
	}
	public void setJ_hobbyS(String j_hobbyS) {
		this.j_hobbyS = j_hobbyS;
	}
	public String getJ_title() {
		return j_title;
	}
	public void setJ_title(String j_title) {
		this.j_title = j_title;
	}
	public Timestamp getJ_date() {
		return j_date;
	}
	public void setJ_date(Timestamp j_date) {
		this.j_date = j_date;
	}
	public Timestamp getJ_Dday() {
		return j_Dday;
	}
	public void setJ_Dday(Timestamp j_Dday) {
		this.j_Dday = j_Dday;
	}
	public Timestamp getJ_Mday() {
		return j_Mday;
	}
	public void setJ_Mday(Timestamp j_Mday) {
		this.j_Mday = j_Mday;
	}
	public int getJ_count() {
		return j_count;
	}
	public void setJ_count(int j_count) {
		this.j_count = j_count;
	}
	public String getJ_cost() {
		return j_cost;
	}
	public void setJ_cost(String j_cost) {
		this.j_cost = j_cost;
	}
	public int getJ_maxmem() {
		return j_maxmem;
	}
	public void setJ_maxmem(int j_maxmem) {
		this.j_maxmem = j_maxmem;
	}
	public int getJ_nowmem() {
		return j_nowmem;
	}
	public void setJ_nowmem(int j_nowmem) {
		this.j_nowmem = j_nowmem;
	}
	public String getJ_content() {
		return j_content;
	}
	public void setJ_content(String j_content) {
		this.j_content = j_content;
	}
	public String getJ_pwd() {
		return j_pwd;
	}
	public void setJ_pwd(String j_pwd) {
		this.j_pwd = j_pwd;
	}
	public int getJ_end() {
		return j_end;
	}
	public void setJ_end(int j_end) {
		this.j_end = j_end;
	}
	public int getJ_admindel() {
		return j_admindel;
	}
	public void setJ_admindel(int j_admindel) {
		this.j_admindel = j_admindel;
	}
}