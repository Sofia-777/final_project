package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.JoinDAO;
import com.javalec.final_hobbyplanet.dto.JoinDTO;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;

// DAO���� sql���� ������
@Service("JoinService")
public class JoinServiceImpl implements JoinService {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public int countJoin(SearchCriteria searchCriteria) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		int total= dao.countJoin(searchCriteria);
		
		return total;
	}

	@Override
	public ArrayList<JoinDTO> listJoinPaging(SearchCriteria searchCriteria) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		ArrayList<JoinDTO> list = dao.listJoinPaging(searchCriteria);
		
		return list;
	}

	@Override
	public void writeJoin(HashMap<String, String> param) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		dao.writeJoin(param);
	}

	@Override
	public JoinDTO viewJoin(HashMap<String, String> param) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		JoinDTO dto = dao.viewJoin(param);
		
		return dto;
	}

	@Override
	public void upCountJoin(HashMap<String, String> param) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);		
		dao.upCountJoin(param);
	}

	@Override
	public void editJoin(HashMap<String, String> param) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);		
		dao.editJoin(param);
	}

	@Override
	public void deleteJoin(HashMap<String, String> param) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		dao.deleteJoin(param);
	}

	@Override
	public JoinDTO checkPwdJoin(HashMap<String, String> param) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		JoinDTO dto = dao.checkPwdJoin(param);
		
		return dto;
	}

	@Override
	public void endJoin(int j_idx) {
		JoinDAO dao = sqlSession.getMapper(JoinDAO.class);
		dao.endJoin(j_idx);
	}
}