package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.ManagerDAO;
import com.javalec.final_hobbyplanet.dto.SearchCriteria;
import com.javalec.final_hobbyplanet.dto.UserDTO;

@Service("ManagerService")
public class ManagerServiceImpl implements ManagerService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public ArrayList<UserDTO> listUserPaging(SearchCriteria searchCriteria) {
		ManagerDAO dao = sqlSession.getMapper(ManagerDAO.class);
		ArrayList<UserDTO> list = dao.listUserPaging(searchCriteria);
		
		return list;
	}

	@Override
	public int countUser(SearchCriteria searchCriteria) {
		ManagerDAO dao = sqlSession.getMapper(ManagerDAO.class);
		int total = dao.countUser(searchCriteria);
		return total;
	}

	@Override
	public int countRegdate() {
		ManagerDAO dao = sqlSession.getMapper(ManagerDAO.class);
		int countRegdate = dao.countRegdate();
		return countRegdate;
	}
	
}
