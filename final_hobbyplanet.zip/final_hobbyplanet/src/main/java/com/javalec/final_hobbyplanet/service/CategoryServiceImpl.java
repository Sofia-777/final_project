package com.javalec.final_hobbyplanet.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.final_hobbyplanet.dao.CategoryDAO;
import com.javalec.final_hobbyplanet.dto.CategoryDTO;

//DAO���� sql���� ������
@Service("CategoryService")
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public ArrayList<CategoryDTO> listCity() {
		CategoryDAO dao = sqlSession.getMapper(CategoryDAO.class);
		ArrayList<CategoryDTO> list = dao.listCity();
		
		return list;
	}

	@Override
	public ArrayList<CategoryDTO> listHobby() {
		CategoryDAO dao = sqlSession.getMapper(CategoryDAO.class);
		ArrayList<CategoryDTO> list = dao.listHobby();
		
		return list;
	}

	@Override
	public void insertCity(HashMap<String, String> param) {
		CategoryDAO dao = sqlSession.getMapper(CategoryDAO.class);
		dao.insertCity(param);
	}
	
	@Override
	public void deleteCity(HashMap<String, String> param) {
		CategoryDAO dao = sqlSession.getMapper(CategoryDAO.class);
		dao.deleteCity(param);
	}

	@Override
	public void insertHobby(HashMap<String, String> param) {
		CategoryDAO dao = sqlSession.getMapper(CategoryDAO.class);
		dao.insertHobby(param);
	}

	@Override
	public void deleteHobby(HashMap<String, String> param) {
		CategoryDAO dao = sqlSession.getMapper(CategoryDAO.class);
		dao.deleteHobby(param);
	}
}